PS3xPAD 0.4 - USB HID Keyboard/Mouse (HEN-oriented source review)

Base: original PS3xPAD 0.4 source.

STATUS
- src/main.c contains the USB HID keyboard/mouse implementation and has been reviewed for the input-state, HID detach, boot-interface and virtual-pad paths.
- The bundled xpad.sprx is NOT the rebuilt USB HID binary and must NOT be used as the finished result. It is intentionally omitted from this review package.
- Build the source with a compatible PS3 LV2/PS3 SDK environment. The original Makefile uses the Sony Cell SDK build rules (ppu-lv2-gcc, cellUsbd, pad LDD APIs). A plain PSL1GHT toolchain alone is not sufficient for these specific headers/stubs.

HEN COMPATIBILITY
- The virtual controller path uses the same PS3 pad LDD/syscall mechanism used by PS3xPAD-style plugins; the relevant pad syscalls are present on retail CEX as well as DEX according to PS3 developer references.
- For PS3HEN, the final SPRX must be properly CEX/HEN-signed. The Makefile signing command is set to the commonly used key revision 04 / auth ID 1070000052000001 / FW target 3.40 profile used for HEN-compatible SPRX signing.
- This source package does NOT claim that an unencrypted PRX or an unsigned SPRX is HEN-ready. The final xpad.sprx must be produced by scetool with the required keys.
- Test first as a manually loaded plugin; do not add it to boot_plugins.txt until the plugin has been confirmed stable.

USB HID LIMITATIONS
- Supports USB HID Boot Protocol keyboard (interface subclass 1, protocol 1) and USB HID Boot Protocol mouse (subclass 1, protocol 2).
- Uses the first suitable interrupt-IN endpoint.
- Standard 8-byte boot keyboard and 3-byte boot mouse reports are expected. Devices that require vendor-specific HID reports, report IDs, or non-boot report parsing are not supported by this implementation.
- Bluetooth keyboard/mouse are not handled by this code.

MAPPING
WASD / arrows = left stick
Mouse X/Y = right stick
Space=Cross, C=Circle, R=Square, 1=Triangle
Q=L1, G=R1, Tab=Select, Enter=Start, Esc=PS, Shift=L3
Mouse left=R2, right=L2, middle=R3

IMPORTANT
PS3 XMB keyboard/mouse support does not make games see the devices as controllers. This plugin reads the USB HID reports and injects them into a virtual PS3 pad using the PS3xPAD LDD mechanism.
